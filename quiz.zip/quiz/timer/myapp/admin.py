from django.contrib import admin

from .models import Questions,user_reg

admin.site.register(user_reg)
admin.site.register(Questions)
