from django.db import models
from django.contrib.auth.models import User

class user_reg(models.Model):
   user_class=models.OneToOneField(User,on_delete=models.CASCADE)
   country=models.CharField(max_length=100)
   phone=models.IntegerField()
   def __str__(self):
       return self.user_class.username


class Questions(models.Model):
    question=models.TextField()
    op1=models.CharField(max_length=100)
    op2=models.CharField(max_length=100)
    op3=models.CharField(max_length=100)
    op4=models.CharField(max_length=100)
    answer=models.CharField(max_length=100)
    def __str__(self):
        return self.question


