from django.shortcuts import render,redirect

from .models import *
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

from django.core.mail import send_mail
from timer.settings import EMAIL_HOST_USER

from django.http import HttpResponse


def user_view(request):
    if request.method=='POST':
        user_name=request.POST.get('username')
        first_name=request.POST.get('first_name')
        last_name=request.POST.get('last_name')
        email=request.POST.get('email')
        country=request.POST.get('country')
        phone=request.POST.get('phone')
        ps1=request.POST.get('ps1')
        ps2=request.POST.get('ps2')

        if ps1==ps2:
            if User.objects.filter(username=user_name).first():
                messages.error(request, 'username already taken or exist')
                return redirect(user_view)
            if User.objects.filter(email=email).first():
                messages.error(request, 'Email already registered')

            user_obj = User(username=user_name, email=email,first_name=first_name,last_name=last_name)
            user_obj.set_password(ps1)
            user_obj.save()
            a=user_reg.objects.create(user_class=user_obj,country=country,phone=phone)
            a.save()
            messages.success(request,'succesfully registered ,Please login to continue')
            return redirect(login_view)

        messages.error(request,'password miss match ,Please try again')
        return redirect(user_reg)
    return render(request,'registration.html')


def login_view(request):
    if request.method == 'POST':
         username= request.POST.get('username')
         ps1 = request.POST.get('ps1')
         user_obj = User.objects.get(username=username)
         if user_obj is None:
             messages.warning(request,'user not found !!!!')
             return redirect(login_view)
         user=authenticate(username=username,password=ps1)
         if user is None:
             messages.success(request, 'Wrong password or username')
             return redirect(login_view)
         profile = user_reg.objects.get(user_class=user)
         messages.success(request,'successfully logged in')
         return render(request,'profile.html',{'x':profile})
    return render(request,'login_page.html')




def quiz_page(request,mail):
    if request.method=='POST':
        li=[]
        q1=request.POST.get('1')
        q2=request.POST.get('2')
        q3=request.POST.get('3')
        q4=request.POST.get('4')
        q5=request.POST.get('5')
        q6=request.POST.get('6')
        q7=request.POST.get('7')
        q8=request.POST.get('8')
        q9=request.POST.get('9')
        q10=request.POST.get('10')

        b=Questions.objects.values_list('answer',flat=True)

        if q1==b[0]:
            li.append(1)
        else:
            li.append(-1)

        if q2 == b[1]:
            li.append(1)
        else:
            li.append(-1)

        if q3 == b[2]:
            li.append(1)
        else:
            li.append(-1)

        if q4 == b[3]:
            li.append(1)
        else:
            li.append(-1)

        if q5 == b[4]:
            li.append(1)
        else:
            li.append(-1)

        if q6 == b[5]:
            li.append(1)
        else:
            li.append(-1)

        if q7 == b[6]:
            li.append(1)
        else:
            li.append(-1)

        if q8 == b[7]:
            li.append(1)
        else:
            li.append(-1)

        if q9 == b[8]:
            li.append(1)
        else:
            li.append(-1)

        if q10 == b[9]:
            li.append(1)
        else:
            li.append(-1)


        a=sum(li)
        if a<0:
            a=0
        else:
            a=a

        result(request,mail,a)
        y=User.objects.get(email=mail)
        z=Questions.objects.all()
        return render(request,'answers.html',{'y':y,'z':z,'a':a})



    a=User.objects.get(email=mail)
    b=Questions.objects.all()
    return render(request,'quiz_page.html',{'x':a,'y':b})




def result(request,mail,score):

    x=User.objects.get(email=mail)
    name=x.first_name
    a=[]
    if int(score)==10:
        a.append(' Wow !!!  പത്തു തലയാ ഇവനു... തനി രാവണൻ !!')
    elif 7<int(score)<10:
        a.append('congradulation ,You are good in english')
    elif 4<int(score)<7:
        a.append('You are average in English,please improve')
    else:
        a.append('sorry,,,you are very bad in english')

    subject = 'Result'
    message = f'Hi {name} \n Thank you for taking talent assessment Platform,Your Score is {score}\n{a[0]}'
    sender = EMAIL_HOST_USER
    receiver = [mail]
    send_mail(subject, message, sender, receiver)


